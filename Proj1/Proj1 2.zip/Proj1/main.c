//
//  main.c
//  Proj1
//
//  Created by 梁轶伦 on 10/14/19.
//  Copyright © 2019 Yilun Liang. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
