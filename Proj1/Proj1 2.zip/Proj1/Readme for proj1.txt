
Yilun Liang
Readme for Project 1

No compiling error, no run time error.

cone( ) to generate the torus.
Motion/ Mouse/ Keyboard to rotate and zoom_in and out.
"i" to zoom in "o" to zoom out.

Small glitches: 
1.The torus can not show up in the center as soon as running the program, but it can be to the origin after drag the size of the window.
2.The program has to run twice to show up since the first time the Mac OS will ask the permission to access the folder.
3. Library did not work perfectly, so implemented them inside the program.
